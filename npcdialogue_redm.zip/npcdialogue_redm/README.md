# ns-npcdialogue
Nopixel 4.0 Inspired NPC Dialogue Script

## For All Updates 
https://discord.gg/j87NTfVGQX

