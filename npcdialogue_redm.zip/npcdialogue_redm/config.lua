Config = {}

Config.npcs = {
    {
        name = "Mark",
        text = "I know hunters as well.",
        job = "Hunter",
        ped = "cs_cabaretmc",
        coords = vector4(2760.816, -1263.413, 47.470, 324.635),
        options = {
            {
                label = "Option 1",
                event = "npc_event",
                type = "client",
                args = {1}
            },
            {
                label = "Option 2",
                event = "command_name",
                type = "command",
                args = {1} 
            },
        }
    },
}